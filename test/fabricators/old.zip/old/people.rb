Fabricator(:person) do
  name {Faker::Name.name}
  password {'123'}
  email {name.to_s.split[0].downcase + '@gmail.com'}
end

Fabricator(:yourvilla_admin, :from => :person) do
  name {'YourVill Admin'}
  password {'123'}
  email {'admin@yourvilla.info'}
end

Fabricator(:myagency_admin, :from => :person) do
  name {'MyAgency Admin'}
  password {'123'}
  email {'admin@realto.be'}
end