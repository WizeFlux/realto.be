Fabricator(:paragraph) do
  content {Faker::Lorem.paragraph(sentence_count = 15)}
end