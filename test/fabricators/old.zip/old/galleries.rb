Fabricator(:gallery) do
  after_create {|gallery| (rand(4)+4).times {gallery.images << Fabricate(:image, :file => File.open("app/assets/images/dummy/estate/#{rand(15)}.jpg"))}}
end