include Rake::DSL

Fabricator(:image) do
  file {nil} 
end