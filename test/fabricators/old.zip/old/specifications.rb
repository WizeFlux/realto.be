Fabricator(:specification) do
  text {Faker::Lorem.paragraph(sentence_count = 2)}
  feature {Feature.all.to_a.sample}
end