Fabricator(:title) do
  content {Faker::Company.name}
end